<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="naijafundsme";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>